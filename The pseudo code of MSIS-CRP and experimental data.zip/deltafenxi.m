close all
subplot(2,2,1)
y=[4 4 4 4 3
    3 3 2 3 2
    2 2 2 2 2
    2 2 2 2 2
    2 2 2 2 1
    2 2 1 2 1
    2 1 1 2 1
    2 1 1 2 1
    1 1 1 2 1
    1 1 1 1 1];
b=bar(y);
grid on;
ch = get(b,'children');
set(gca,'XTickLabel',{'0.1', '0.2', '0.3' , '0.4', '0.5', '0.6', '0.7', '0.8', '0.9', '1.0'})
% set(ch,'FaceVertexCData',[1 0 1;0 0 0;])
% set(gca,'XTickLabelRotation',30);%46是字体的旋转角度
legend('e_{1}','e_{2}','e_{3}','e_{4}','e_{5}');
xlabel('Values of \delta ');
ylabel('Scale numbers of c_{1}');



subplot(2,2,2)
y=[4 4 4 4 5
    3 3 2 3 3
    2 2 2 2 3
    2 2 2 2 2
    2 2 2 2 2
    2 2 1 2 2
    2 2 1 2 2
    2 2 1 1 2
    1 1 1 1 2
    1 1 1 1 1];
b=bar(y);
grid on;
ch = get(b,'children');
set(gca,'XTickLabel',{'0.1', '0.2', '0.3' , '0.4', '0.5', '0.6', '0.7', '0.8', '0.9', '1.0'})
% set(ch,'FaceVertexCData',[1 0 1;0 0 0;])
% set(gca,'XTickLabelRotation',30);%46是字体的旋转角度
legend('e_{1}','e_{2}','e_{3}','e_{4}','e_{5}');
xlabel('Values of \delta ');
ylabel('Scale numbers of c_{2}');



subplot(2,2,3)
y=[5 4 3 4 5
    4 3 2 3 3
    2 3 2 2 2
    2 2 2 2 2
    2 2 2 2 2
    2 2 2 2 2
    2 2 1 2 2
    2 2 1 2 1
    2 1 1 1 1
    1 1 1 1 1];
b=bar(y);
grid on;
ch = get(b,'children');
set(gca,'XTickLabel',{'0.1', '0.2', '0.3' , '0.4', '0.5', '0.6', '0.7', '0.8', '0.9', '1.0'})
% set(ch,'FaceVertexCData',[1 0 1;0 0 0;])
% set(gca,'XTickLabelRotation',30);%46是字体的旋转角度
legend('e_{1}','e_{2}','e_{3}','e_{4}','e_{5}');
xlabel('Values of \delta ');
ylabel('Scale numbers of c_{3}');



subplot(2,2,4)
y=[4 4 5 4 5
    3 3 4 3 3
    2 2 3 2 2
    2 2 2 2 2
    2 2 2 2 2
    2 2 2 2 2
    1 1 2 2 1
    1 1 2 2 1
    1 1 2 2 1
    1 1 1 1 1];
b=bar(y);
grid on;
ch = get(b,'children');
set(gca,'XTickLabel',{'0.1', '0.2', '0.3' , '0.4', '0.5', '0.6', '0.7', '0.8', '0.9', '1.0'})
% set(ch,'FaceVertexCData',[1 0 1;0 0 0;])
% set(gca,'XTickLabelRotation',30);%46是字体的旋转角度
legend('e_{1}','e_{2}','e_{3}','e_{4}','e_{5}');
xlabel('Values of \delta ');
ylabel('Scale numbers of c_{4}');