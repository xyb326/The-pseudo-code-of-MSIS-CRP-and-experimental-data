clear
clc
close all
figure('Position',[150,100,750,650]);

z=[ 11.9843 11.9843 11.6743 0
    13.9843 13.9843 13.6743 0
    15.8243 15.8243 15.5143 0
    15.8243 15.8243 15.5143 0]';

color_matrix=[100 255 150;50 152 65; 129 211 176;108 99 117;50 152 65]/255;

h=bar3(z,0.6);

print(figureHandle,'eg1.png','-r300','-dpng');
hXLabel=[0.91 0.92 0.93 0.94 0.95];
hYLabel=[0.91 0.92 0.93 0.94 0.95];
hZLabel=[0.91 0.92 0.93 0.94 0.95];
set([hXLabel, hYLabel,hZLabel])
axis([-inf inf -inf inf 60 100])
for n=1:numel(h)
    cdata=get(h(n),'zdata');
    set(h(n),'zdata',cdata,'facecolor',color_matrix(n,:));
end
set(gca,'yticklabel',[0.91 0.92 0.93 0.94 0.95]);
set(gca,'xticklabel',[1 2 3 4 5]);
legend({'A_1','A_2','A_3','A_4'})
x=1:5;
y=0.91:0.01:0.95;
for i=1:5
    for k=1:5
       z(i,k)=A(i,k);          
    end 
end
surf(x,y,z,'EdgeColor','interp')
title('Changes of the parameter  ζ for ranking');
xlabel('\alpha');
ylabel('$\overline{GCI}$','interpreter','latex');
zlabel('Modification cost');