clc
clear
close all
A1=[0.8 0.1
    0.4 0.2];
A=[0.5 0.5
    0.5 0.5];
a=2;b=2;


delta=0.1;
QGCI=0.8;

for i=1:a*b
    if A1(i)<A(i)
        t1(i)=1;%%%%%目标函数的系数
        t2(i)=-1;
    else 
        t1(i)=-1;%%%%%目标函数的系数
        t2(i)=1;
    end
end
for i=1:a*b
    A1t2(i)=t2(i)*A1(i)
end
Cost11=sum(sum(A1t2));%%%%%目标函数的常数量

for i=1:a*b
    c(i)=t1(i);%%%%%目标函数的系数
end
c=c'
for j=1:a*b
    bbb1(1,j)=t2(j);%%%%%最后一个约束条件系数
    AA1(j)=t1(j)*A(j)
end
yueshuchangshu=sum(sum(AA1));

for j=1:a*b
aeq(1,j)=bbb1(1,j);%%%%%所有约束条件系数
end
for i=1:a*b
   beq=(1-QGCI)*a*b-yueshuchangshu;
end
% for i=1:a*b
%     vlb(i)=max(A1(i)-delta,0);
%     vub(i)=min(A1(i)+delta,1);%%%%%%上下界限
% end
for i=1:a*b
    if A1(i)<A(i)
      vlb(i)=A1(i);
      vub(i)=min(A1(i)+delta,A(i));
    else 
      vlb(i)=max(A(i),A1(i)-delta); 
      vub(i)=A1(i);%%%%%%上下界限
    end
end



[x1,val]=linprog(c,aeq,beq,[],[],vlb',vub')






for i=1:a*b
costA1(i)=abs(x1(i)-A1(i))
end
CostA1=sum(sum(costA1))
% clc,clear
% c=1:4;
% c=[c,c]';
% aeq=[1 -1 -1 1; 1 -1 1 -3; 1 -1 -2 3;];
% beq=[0 1 -1/2];
% aeq=[aeq,-aeq];
% [uv,val]=linprog(c,[],[],aeq,beq,zeros(8,1));
% x=uv(1:4)-uv(5:end)
