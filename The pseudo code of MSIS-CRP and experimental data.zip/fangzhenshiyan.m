clc
clear 
close all
% load('P1','P1');
% load('P2','P2');
% load('P3','P3');
% load('P4','P4');
% load('P5','P5');    


y=0;CostFZ=[];ttt=1:1000;
while y<1000
P1=100*rand(48,4);
P2=100*rand(48,4);
P3=100*rand(48,4);
P4=100*rand(48,4);
P5=100*rand(48,4);
%%%%%%%%%随机加载5个决策者更新后



D1=P1;D2=P2;D3=P3;D4=P4;D5=P5;
K1=[4,4,5,4];
K2=[4,4,4,4];
K3=[4,4,3,5];
K4=[4,4,4,4];
K5=[3,5,5,5];
[a,b]=size(P1)

t0=cputime;
for i1=1:b
    for i2=1:a
        for i3=1:a
            w1{i1}(i2,i3)=abs(P1(i2,i1)-P1(i3,i1))
            w2{i1}(i2,i3)=abs(P2(i2,i1)-P2(i3,i1))
            w3{i1}(i2,i3)=abs(P3(i2,i1)-P3(i3,i1))
            w4{i1}(i2,i3)=abs(P4(i2,i1)-P4(i3,i1))
            w5{i1}(i2,i3)=abs(P5(i2,i1)-P5(i3,i1))
        end
    end
end
for i=1:b
    C1(i)=sum(sum(w1{i}));
    C2(i)=sum(sum(w2{i}));
    C3(i)=sum(sum(w3{i}));
    C4(i)=sum(sum(w4{i}));
    C5(i)=sum(sum(w5{i}));
end
W(1)=C1*K1'/sum(sum(K1));
W(2)=C2*K2'/sum(sum(K2));
W(3)=C3*K3'/sum(sum(K3));
W(4)=C4*K4'/sum(sum(K4));
W(5)=C5*K5'/sum(sum(K5));
W=W/sum(sum(W));%%%%%%%%%%%%%%%%%%%%%决策者权重

P=W(1)*P1+W(2)*P2+W(3)*P3+W(4)*P4+W(5)*P5;%%%%%%群体意见

for i=1:a
    for j=1:b
        tt1(i,j)=min(P(i,j),P1(i,j))/max(P(i,j),P1(i,j));
        tt2(i,j)=min(P(i,j),P2(i,j))/max(P(i,j),P2(i,j));
        tt3(i,j)=min(P(i,j),P3(i,j))/max(P(i,j),P3(i,j));
        tt4(i,j)=min(P(i,j),P4(i,j))/max(P(i,j),P4(i,j));
        tt5(i,j)=min(P(i,j),P5(i,j))/max(P(i,j),P5(i,j));
    end
end
tt1=sum(tt1)/a
tt2=sum(tt2)/a
tt3=sum(tt3)/a
tt4=sum(tt4)/a
tt5=sum(tt5)/a
GCI1=tt1*K1'/sum(sum(K1));
GCI2=tt2*K2'/sum(sum(K2));
GCI3=tt3*K3'/sum(sum(K3));
GCI4=tt4*K4'/sum(sum(K4));
GCI5=tt5*K5'/sum(sum(K5));
GCI0=W(1)*GCI1+W(2)*GCI2+W(3)*GCI3+W(4)*GCI4+W(5)*GCI5;




% % % PP=P5  %%%%%%依次检验gama1-5的值
% % % GCI11=[];
% % % for k=-8:0.01:-6
% % %     P5=PP
% % %     for i=1:a
% % %         for j=1:b
% % %             P5(i,j)=P5(i,j)+k
% % %         end
% % %     end
% % %     for i=1:a
% % %         for j=1:b
% % %             tt1(i,j)=min(P(i,j),P1(i,j))/max(P(i,j),P1(i,j));
% % %             tt2(i,j)=min(P(i,j),P2(i,j))/max(P(i,j),P2(i,j));
% % %             tt3(i,j)=min(P(i,j),P3(i,j))/max(P(i,j),P3(i,j));
% % %             tt4(i,j)=min(P(i,j),P4(i,j))/max(P(i,j),P4(i,j));
% % %             tt5(i,j)=min(P(i,j),P5(i,j))/max(P(i,j),P5(i,j));
% % %         end
% % %     end
% % %     tt1=sum(tt1)/a
% % %     tt2=sum(tt2)/a
% % %     tt3=sum(tt3)/a
% % %     tt4=sum(tt4)/a
% % %     tt5=sum(tt5)/a
% % %     GCI1=tt1*K1'/sum(sum(K1));
% % %     GCI2=tt2*K2'/sum(sum(K2));
% % %     GCI3=tt3*K3'/sum(sum(K3));
% % %     GCI4=tt4*K4'/sum(sum(K4));
% % %     GCI5=tt5*K5'/sum(sum(K5));
% % %     GCI11=[GCI11 GCI5]
% % % end

gama1=-1.27;gama2=4.17;gama3=-7.18;gama4=4.96;gama5=-6.65;%%%%%全局共识反馈


for i=1:a
    for j=1:b
        P1(i,j)=P1(i,j)+gama1;
        P2(i,j)=P2(i,j)+gama2;
        P3(i,j)=P3(i,j)+gama3;
        P4(i,j)=P4(i,j)+gama4;
        P5(i,j)=P5(i,j)+gama5;
    end
end


P=W(1)*P1+W(2)*P2+W(3)*P3+W(4)*P4+W(5)*P5;%%%%%%群体意见


for i=1:a
    for j=1:b
        tt1(i,j)=min(P(i,j),P1(i,j))/max(P(i,j),P1(i,j));
        tt2(i,j)=min(P(i,j),P2(i,j))/max(P(i,j),P2(i,j));
        tt3(i,j)=min(P(i,j),P3(i,j))/max(P(i,j),P3(i,j));
        tt4(i,j)=min(P(i,j),P4(i,j))/max(P(i,j),P4(i,j));
        tt5(i,j)=min(P(i,j),P5(i,j))/max(P(i,j),P5(i,j));
    end
end
tt1=sum(tt1)/a
tt2=sum(tt2)/a
tt3=sum(tt3)/a
tt4=sum(tt4)/a
tt5=sum(tt5)/a
GCI1=tt1*K1'/sum(sum(K1));
GCI2=tt2*K2'/sum(sum(K2));
GCI3=tt3*K3'/sum(sum(K3));
GCI4=tt4*K4'/sum(sum(K4));
GCI5=tt5*K5'/sum(sum(K5));
GCI=W(1)*GCI1+W(2)*GCI2+W(3)*GCI3+W(4)*GCI4+W(5)*GCI5;



%%%%%%%%下面开始局部共识反馈
sita=[];x=0;
T=100;
for t=1:T
    x=x+1/t^2;
    sita=[sita x];
end
sita=sita*6/pi^2;  %%%%%%t时刻的调整参数


sunshi=sum(sum(abs(P1-P)))*W(1)+sum(sum(abs(P2-P)))*W(2)+sum(sum(abs(P3-P)))*W(3)+sum(sum(abs(P4-P)))*W(4)+sum(sum(abs(P5-P)))*W(5)
Sun=sunshi/(100*a*b)


for t=1:T
    Sunshi(t)=sita(1,t)*Sun
end

Shouyi=[];GCI00=GCI;
for t=1:T
for i=1:a
    for j=1:b
        P1(i,j)=(1-sita(t))*P1(i,j)+sita(t)*P(i,j);
        P2(i,j)=(1-sita(t))*P2(i,j)+sita(t)*P(i,j);
        P3(i,j)=(1-sita(t))*P3(i,j)+sita(t)*P(i,j);
        P4(i,j)=(1-sita(t))*P4(i,j)+sita(t)*P(i,j);
        P5(i,j)=(1-sita(t))*P5(i,j)+sita(t)*P(i,j);
    end
end


P=W(1)*P1+W(2)*P2+W(3)*P3+W(4)*P4+W(5)*P5;%%%%%%群体意见

for i=1:a
    for j=1:b
        tt1(i,j)=min(P(i,j),P1(i,j))/max(P(i,j),P1(i,j));
        tt2(i,j)=min(P(i,j),P2(i,j))/max(P(i,j),P2(i,j));
        tt3(i,j)=min(P(i,j),P3(i,j))/max(P(i,j),P3(i,j));
        tt4(i,j)=min(P(i,j),P4(i,j))/max(P(i,j),P4(i,j));
        tt5(i,j)=min(P(i,j),P5(i,j))/max(P(i,j),P5(i,j));
    end
end
tt1=sum(tt1)/a
tt2=sum(tt2)/a
tt3=sum(tt3)/a
tt4=sum(tt4)/a
tt5=sum(tt5)/a
GCI1=tt1*K1'/sum(sum(K1));
GCI2=tt2*K2'/sum(sum(K2));
GCI3=tt3*K3'/sum(sum(K3));
GCI4=tt4*K4'/sum(sum(K4));
GCI5=tt5*K5'/sum(sum(K5));
GCI=W(1)*GCI1+W(2)*GCI2+W(3)*GCI3+W(4)*GCI4+W(5)*GCI5;
GCII=GCI-GCI00;
Shouyi=[Shouyi GCII]
end

time=cputime-t0

YYYYY=Shouyi-Sunshi

for i=1:T
    if YYYYY(i)==max(max(YYYYY))
        xxxxx=i;
    end
end     %%%%%%t=3时达成均衡状态。

Cost=sum(sum(abs(P1-D1)))+sum(sum(abs(P2-D2)))+sum(sum(abs(P3-D3)))+sum(sum(abs(P4-D4)))+sum(sum(abs(P5-D5)))
Cost=Cost/100

CostFZ=[CostFZ Cost]
y=y+1
end




plot(ttt,CostFZ,'-*k')

hold on
for i=1:1000
   zzz(i)=mean(CostFZ)
end
plot(ttt,zzz,'-pb')
xlabel('Number of randomized experiments')
ylabel('Adjustment distance')