clc
clear
close all
JS=xlsread('教师.xlsx','sheet1','H2:GQ11');
for  j=1:192
    js(1,j)=0;
end
for i=1:10
    for  j=1:192
        js(1,j)=js(1,j)+JS(i,j);
    end
end
js=js/10;
for i=1:48
    for j=1:4
        D1(i,j)=js(1,4*(i-1)+j);   %%%%%%%%决策者1原始数据
    end
end

YS=xlsread('医生.xlsx','sheet1','H2:GQ7');
for  j=1:192
    ys(1,j)=0;
end
for i=1:6
    for  j=1:192
        ys(1,j)=ys(1,j)+YS(i,j);
    end
end
ys=ys/6;
for i=1:48
    for j=1:4
        D2(i,j)=ys(1,4*(i-1)+j);   %%%%%%%%决策者2原始数据
    end
end

GR=xlsread('工人.xlsx','sheet1','H2:GQ7');
for  j=1:192
    gr(1,j)=0;
end
for i=1:6
    for  j=1:192
        gr(1,j)=gr(1,j)+GR(i,j);
    end
end
gr=gr/6;
for i=1:48
    for j=1:4
        D3(i,j)=gr(1,4*(i-1)+j);   %%%%%%%%决策者3原始数据
    end
end

SR=xlsread('商人.xlsx','sheet1','H2:GQ9');
for  j=1:192
    sr(1,j)=0;
end
for i=1:8
    for  j=1:192
        sr(1,j)=sr(1,j)+SR(i,j);
    end
end
sr=sr/8;
for i=1:48
    for j=1:4
        D4(i,j)=sr(1,4*(i-1)+j);   %%%%%%%%决策者4原始数据
    end
end

SG=xlsread('司机.xlsx','sheet1','H2:GQ6');
for  j=1:192
    sj(1,j)=0;
end
for i=1:5
    for  j=1:192
        sj(1,j)=sj(1,j)+SG(i,j);
    end
end
sj=sj/5;
for i=1:48
    for j=1:4
        D5(i,j)=sj(1,4*(i-1)+j);   %%%%%%%%决策者5原始数据
    end
end


save('D1','D1');
save('D2','D2');
save('D3','D3');
save('D4','D4');
save('D5','D5');    %%%%%%%%%保存5个决策者的原始数据