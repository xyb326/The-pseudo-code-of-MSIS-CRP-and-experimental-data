clc
clear 
close all
load('D1','D1');
load('D2','D2');
load('D3','D3');
load('D4','D4');
load('D5','D5');    %%%%%%%%%加载5个决策者的原始数据
A=D1
[a,b]=size(A);
M11=max(A);

delta=0.1; 
jicha=max(max(A))-min(min(A));
r=delta*jicha;%%%%%截断距离
A1=A;           %%%%%%第一尺度信息。

for j=1:b
tt=0;t=0;   
while tt<a
BB1=[];BB2=[];
for i=1:a
    if A(i,j)<=M11(1,j)&A(i,j)>=M11(1,j)-r
        AA(i,j)=1+t;
        bb1=A(i,j)
        BB1=[BB1 bb1]
        zhong=median(BB1)
    end
    if A(i,j)<M11(1,j)-r
        AA(i,j)=0
        bb2=A(i,j)
        BB2=[BB2 bb2]
    end
end
for i=1:a
    if  AA(i,j)==1+t
        A(i,j)=zhong;
    end
end
if length(BB2)>=1
M11(1,j)=max(max(BB2));
else
    M11(1,j)=0
end
t=t+1

for i=1:a
    if  AA(i,j)>0
        T(i,1)=1;
    else
        T(i,1)=0;
    end
end
tt=sum(sum(T))
end
end           
A2=A;           %%%%%%第二尺度信息。



M11=max(A);
r=2*delta*jicha;%%%%%截断距离


for j=1:b
tt=0;t=0;   
while tt<a
BB1=[];BB2=[];
for i=1:a
    if A(i,j)<=M11(1,j)&A(i,j)>=M11(1,j)-r
        AA(i,j)=1+t;
        bb1=A(i,j)
        BB1=[BB1 bb1]
        zhong=median(BB1)
    end
    if A(i,j)<M11(1,j)-r
        AA(i,j)=0
        bb2=A(i,j)
        BB2=[BB2 bb2]
    end
end
for i=1:a
    if  AA(i,j)==1+t
        A(i,j)=zhong;
    end
end
if length(BB2)>=1
M11(1,j)=max(max(BB2));
else
    M11(1,j)=0
end
t=t+1

for i=1:a
    if  AA(i,j)>0
        T(i,1)=1;
    else
        T(i,1)=0;
    end
end
tt=sum(sum(T))
end
end           
A3=A;           %%%%%%第三尺度信息。



M11=max(A);
r=3*delta*jicha;%%%%%截断距离


for j=1:b
tt=0;t=0;   
while tt<a
BB1=[];BB2=[];
for i=1:a
    if A(i,j)<=M11(1,j)&A(i,j)>=M11(1,j)-r
        AA(i,j)=1+t;
        bb1=A(i,j)
        BB1=[BB1 bb1]
        zhong=median(BB1)
    end
    if A(i,j)<M11(1,j)-r
        AA(i,j)=0
        bb2=A(i,j)
        BB2=[BB2 bb2]
    end
end
for i=1:a
    if  AA(i,j)==1+t
        A(i,j)=zhong;
    end
end
if length(BB2)>=1
M11(1,j)=max(max(BB2));
else
    M11(1,j)=0
end
t=t+1

for i=1:a
    if  AA(i,j)>0
        T(i,1)=1;
    else
        T(i,1)=0;
    end
end
tt=sum(sum(T))
end
end           
A4=A;           %%%%%%第四尺度信息。


M11=max(A);
r=4*delta*jicha;%%%%%截断距离


for j=1:b
tt=0;t=0;   
while tt<a
BB1=[];BB2=[];
for i=1:a
    if A(i,j)<=M11(1,j)&A(i,j)>=M11(1,j)-r
        AA(i,j)=1+t;
        bb1=A(i,j)
        BB1=[BB1 bb1]
        zhong=median(BB1)
    end
    if A(i,j)<M11(1,j)-r
        AA(i,j)=0
        bb2=A(i,j)
        BB2=[BB2 bb2]
    end
end
for i=1:a
    if  AA(i,j)==1+t
        A(i,j)=zhong;
    end
end
if length(BB2)>=1
M11(1,j)=max(max(BB2));
else
    M11(1,j)=0
end
t=t+1

for i=1:a
    if  AA(i,j)>0
        T(i,1)=1;
    else
        T(i,1)=0;
    end
end
tt=sum(sum(T))
end
end           
A5=A;           %%%%%%第五尺度信息。



M11=max(A);
r=5*delta*jicha;%%%%%截断距离


for j=1:b
tt=0;t=0;   
while tt<a
BB1=[];BB2=[];
for i=1:a
    if A(i,j)<=M11(1,j)&A(i,j)>=M11(1,j)-r
        AA(i,j)=1+t;
        bb1=A(i,j)
        BB1=[BB1 bb1]
        zhong=median(BB1)
    end
    if A(i,j)<M11(1,j)-r
        AA(i,j)=0
        bb2=A(i,j)
        BB2=[BB2 bb2]
    end
end
for i=1:a
    if  AA(i,j)==1+t
        A(i,j)=zhong;
    end
end
if length(BB2)>=1
M11(1,j)=max(max(BB2));
else
    M11(1,j)=0
end
t=t+1

for i=1:a
    if  AA(i,j)>0
        T(i,1)=1;
    else
        T(i,1)=0;
    end
end
tt=sum(sum(T))
end
end           
A6=A;           %%%%%%第六尺度信息。

%%%%%%决策者1尺度数为4,4,5,4
yita=1;%%%%计算尺度权重参数
for i=1:3
    ck3(i)=(i/3)^yita-((i-1)/3)^yita;
end
for i=1:4
    ck4(i)=(i/4)^yita-((i-1)/4)^yita;
end
for i=1:5
    ck5(i)=(i/5)^yita-((i-1)/5)^yita;
end

for i=1:a
        p1(i,1)=A1(i,1)*ck4(1)+A2(i,1)*ck4(2)+A3(i,1)*ck4(3)+A4(i,1)*ck4(4);
        p2(i,1)=A1(i,2)*ck4(1)+A2(i,2)*ck4(2)+A3(i,2)*ck4(3)+A4(i,2)*ck4(4);
        p3(i,1)=A1(i,3)*ck5(1)+A2(i,3)*ck5(2)+A3(i,3)*ck5(3)+A4(i,3)*ck5(4)+A5(i,3)*ck5(5);
        p4(i,1)=A1(i,4)*ck4(1)+A2(i,4)*ck4(2)+A3(i,4)*ck4(3)+A4(i,4)*ck4(4);
end
P1=[p1,p2,p3,p4];
save('P1','P1')

