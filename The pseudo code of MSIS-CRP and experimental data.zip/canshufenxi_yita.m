clc
clear
close all
Ck3=[];Ck4=[];Ck5=[];Ck6=[];
for yita=0.1:0.1:1;%%%%计算尺度权重参数
for i=1:3
    ck3(i)=(i/3)^yita-((i-1)/3)^yita;
end
Ck3=[Ck3;ck3]

for i=1:4
    ck4(i)=(i/4)^yita-((i-1)/4)^yita;
end
Ck4=[Ck4;ck4]

for i=1:5
    ck5(i)=(i/5)^yita-((i-1)/5)^yita;
end
Ck5=[Ck5;ck5]

for i=1:6
    ck6(i)=(i/5)^yita-((i-1)/5)^yita;
end
Ck6=[Ck6;ck6]
end



figure('Position',[150,100,750,650]);

z1=Ck3';

color_matrix=[100 255 150;50 152 65; 129 211 176;108 99 117;50 152 65]/255;

h=bar3(z1,0.6);

print(figureHandle,'eg1.png','-r300','-dpng');





% figure('Position',[150,100,750,650]);
% 
% z1=Ck4';
% 
% color_matrix=[100 255 150;50 152 65; 129 211 176;108 99 117;50 152 65]/255;
% 
% h=bar3(z1,0.6);
% 
% print(figureHandle,'eg1.png','-r300','-dpng');




% figure('Position',[150,100,750,650]);
% 
% z1=Ck5';
% 
% color_matrix=[100 255 150;50 152 65; 129 211 176;108 99 117;50 152 65]/255;
% 
% h=bar3(z1,0.6);
% 
% print(figureHandle,'eg1.png','-r300','-dpng');



% figure('Position',[150,100,750,650]);
% z1=Ck6';
% color_matrix=[100 255 150;50 152 65; 129 211 176;108 99 117;50 152 65]/255;
% 
% h=bar3(z1,0.6);
% 
% print(figureHandle,'eg1.png','-r300','-dpng');



