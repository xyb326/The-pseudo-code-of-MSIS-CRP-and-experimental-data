clc
clear
close all
% A=rand(10,2)

A=[0.3157 0.0759
    0.8308 0.0540
    0.5853 0.5308
    0.5497 0.7792
    0.9172 0.9340
    0.2858 0.1299
    0.7572 0.5688
    0.7537 0.4694
    0.3804 0.0119
    0.5678 0.3371]

[a,b]=size(A);
M11=max(A);
m11=min(A);
jicha=max(max(A(:,2)))-min(min(A(:,2)));
r=0.1*jicha;%%%%%截断距离
A1=A;           %%%%%%第一尺度信息。

for j=1:b
tt=0;t=0;   
while tt<a
BB1=[];BB2=[];
for i=1:a
    if A(i,j)<=M11(1,j)&A(i,j)>=M11(1,j)-r
        AA(i,j)=1+t;
        bb1=A(i,j)
        BB1=[BB1 bb1]
        zhong=median(BB1)
    end
    if A(i,j)<M11(1,j)-r
        AA(i,j)=0
        bb2=A(i,j)
        BB2=[BB2 bb2]
    end
end
for i=1:a
    if  AA(i,j)==1+t
        A(i,j)=zhong;
    end
end
if length(BB2)>=1
M11(1,j)=max(max(BB2));
else
    M11(1,j)=0
end
t=t+1

for i=1:a
    if  AA(i,j)>0
        T(i,1)=1;
    else
        T(i,1)=0;
    end
end
tt=sum(sum(T))
end
end           
A2=A;           %%%%%%第二尺度信息。



M11=max(A);
r=0.2*jicha;%%%%%截断距离


for j=1:b
tt=0;t=0;   
while tt<a
BB1=[];BB2=[];
for i=1:a
    if A(i,j)<=M11(1,j)&A(i,j)>=M11(1,j)-r
        AA(i,j)=1+t;
        bb1=A(i,j)
        BB1=[BB1 bb1]
        zhong=median(BB1)
    end
    if A(i,j)<M11(1,j)-r
        AA(i,j)=0
        bb2=A(i,j)
        BB2=[BB2 bb2]
    end
end
for i=1:a
    if  AA(i,j)==1+t
        A(i,j)=zhong;
    end
end
if length(BB2)>=1
M11(1,j)=max(max(BB2));
else
    M11(1,j)=0
end
t=t+1

for i=1:a
    if  AA(i,j)>0
        T(i,1)=1;
    else
        T(i,1)=0;
    end
end
tt=sum(sum(T))
end
end           
A3=A;           %%%%%%第三尺度信息。



M11=max(A);
r=0.3*jicha;%%%%%截断距离


for j=1:b
tt=0;t=0;   
while tt<a
BB1=[];BB2=[];
for i=1:a
    if A(i,j)<=M11(1,j)&A(i,j)>=M11(1,j)-r
        AA(i,j)=1+t;
        bb1=A(i,j)
        BB1=[BB1 bb1]
        zhong=median(BB1)
    end
    if A(i,j)<M11(1,j)-r
        AA(i,j)=0
        bb2=A(i,j)
        BB2=[BB2 bb2]
    end
end
for i=1:a
    if  AA(i,j)==1+t
        A(i,j)=zhong;
    end
end
if length(BB2)>=1
M11(1,j)=max(max(BB2));
else
    M11(1,j)=0
end
t=t+1

for i=1:a
    if  AA(i,j)>0
        T(i,1)=1;
    else
        T(i,1)=0;
    end
end
tt=sum(sum(T))
end
end           
A4=A;           %%%%%%第四尺度信息。


M11=max(A);
r=0.4*jicha;%%%%%截断距离


for j=1:b
tt=0;t=0;   
while tt<a
BB1=[];BB2=[];
for i=1:a
    if A(i,j)<=M11(1,j)&A(i,j)>=M11(1,j)-r
        AA(i,j)=1+t;
        bb1=A(i,j)
        BB1=[BB1 bb1]
        zhong=median(BB1)
    end
    if A(i,j)<M11(1,j)-r
        AA(i,j)=0
        bb2=A(i,j)
        BB2=[BB2 bb2]
    end
end
for i=1:a
    if  AA(i,j)==1+t
        A(i,j)=zhong;
    end
end
if length(BB2)>=1
M11(1,j)=max(max(BB2));
else
    M11(1,j)=0
end
t=t+1

for i=1:a
    if  AA(i,j)>0
        T(i,1)=1;
    else
        T(i,1)=0;
    end
end
tt=sum(sum(T))
end
end           
A5=A;           %%%%%%第五尺度信息。



M11=max(A);
r=0.5*jicha;%%%%%截断距离


for j=1:b
tt=0;t=0;   
while tt<a
BB1=[];BB2=[];
for i=1:a
    if A(i,j)<=M11(1,j)&A(i,j)>=M11(1,j)-r
        AA(i,j)=1+t;
        bb1=A(i,j)
        BB1=[BB1 bb1]
        zhong=median(BB1)
    end
    if A(i,j)<M11(1,j)-r
        AA(i,j)=0
        bb2=A(i,j)
        BB2=[BB2 bb2]
    end
end
for i=1:a
    if  AA(i,j)==1+t
        A(i,j)=zhong;
    end
end
if length(BB2)>=1
M11(1,j)=max(max(BB2));
else
    M11(1,j)=0
end
t=t+1

for i=1:a
    if  AA(i,j)>0
        T(i,1)=1;
    else
        T(i,1)=0;
    end
end
tt=sum(sum(T))
end
end           
A6=A;           %%%%%%第六尺度信息。